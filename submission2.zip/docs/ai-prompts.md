# AI Prompts Log — ICT3009 Coursework  

**Bitcoin Transaction Verification on Ethereum**

> This document summarises how AI tools were used during the development of this coursework, in accordance with the ICT3009 specification.
>
> AI was used as a **planning, tutoring, and code-review assistant**, not as a black-box code generator.
> The core principle of my workflow was *incremental implementation + continuous testing*, which made the code easier to understand, debug, and justify.

---

## Overall AI Usage Strategy

Rather than asking for complete, finished smart contracts in one step, I deliberately used AI in a **step-by-step, method-driven way**:

- First to **plan and structure** the work,
- Then to **scaffold code and tests**,
- Then to **implement individual functions one at a time**,
- With tests executed after each small change.

This approach allowed me to:

- Validate correctness early,
- Isolate bugs to a single function,
- Understand and justify each implementation decision,
- Avoid large, hard-to-debug code dumps.

---

## Prompt 1 — Project setup and global plan

### Goal

Obtain a clear, end-to-end roadmap for completing the coursework, including:

- recommended tools,
- file structure,
- task ordering,
- and a workflow suitable for limited time and limited prior blockchain experience.

### Prompt

**Prompt:**  
Blockchain and smart contracts final assignment. I’ll upload the assignment description. First off, create a set of structured steps to follow to complete the assignment fully. Be thorough, and assume that I have little knowledge of blockchain. Recommend the simplest and most appropriate tools and approaches. This chat will then be used as a hub for follow-up questions. Be explicit about terminal commands, file structure, and where actions should be performed.

### How I used the response

- Used the output as a **high-level roadmap** for the entire coursework.
- Followed the suggested task ordering.
- Adopted the recommendation to **start documenting AI usage early**, which resulted in this log.

### Outcome

- Environment setup (Foundry, repository structure).
- Clear separation of tasks.
- Decision to start with a reusable Bitcoin utility library before higher-level logic.

---

## Prompt 2 — Phase 2 planning: BTCUtils.sol (scaffolding, not full implementations)

### Goal

Design Phase 2 (Bitcoin helper utilities) in a way that:

- supports later tasks (Merkle proofs, block headers, transaction parsing),
- avoids repeated parsing logic,
- and is easy to validate with unit tests.

### Prompt

I’m doing ICT3009 “Bitcoin Transaction Verification on Ethereum”. Phase 2 is to build `BTCUtils.sol` first, since Tasks 1, 2, and 4 rely heavily on byte parsing and hashing.

Act as a senior reviewer and tutor. Provide:

- a step-by-step implementation order,
- a code skeleton with function signatures, comments, and TODO markers,
- and a concrete test plan with known Bitcoin test vectors.

Do **not** generate full implementations yet — I want to implement and test each function incrementally.

### Why I avoided full implementations at this stage

Requesting only **skeletons and test vectors** (instead of full code) ensured that:

- each function could be implemented and tested independently,
- failures could be isolated immediately,
- and the resulting code remained easy to explain and justify.

### How I used the response

- Implemented utilities in the recommended order.
- Added and ran tests after each function.
- Used known Bitcoin test vectors to verify correctness (endianness, VarInt decoding, hashing).

### Outcome

- A stable, reusable Bitcoin utility library.
- High confidence in correctness before moving to Tasks 1, 2, and 4.

---

## Incremental implementation methodology (key principle)

For all later development steps, including BTCUtils and subsequent tasks, I followed this pattern:

1. Ask AI for guidance or implementation **for a single function only**.
2. Paste and integrate the code manually.
3. Add focused unit tests for that function.
4. Run Foundry tests immediately.
5. Proceed only once the tests pass.

This workflow made debugging significantly easier, since any failure could be traced to the most recently added logic.

---

## Optional follow-up prompt templates

The following templates were used when needed, without logging every individual instance.

### Targeted code review

```text
Here is my current Solidity file and test file.

Please:
1) Identify correctness risks (bounds checks, endianness, offsets).
2) Suggest minimal changes for a single function.
3) Propose a small number of additional tests that would catch likely bugs.

Do not rewrite the entire file.


more prompts:
I’m working on ICT3009 Task 2 (Bitcoin Block Header Verification System). Give me a clear, step-by-step approach (no code yet) to implement submitBlockHeader(bytes header) and getBlockHeight(bytes32 blockHash) in Solidity/Foundry. Cover: how to deserialize the 80-byte Bitcoin header, compute block hash (double SHA256) and handle endianness, decode bits into a target, verify PoW (hash <= target) and enforce “minimum difficulty 70 billion” (how to compare that to bits/target), verify prevBlockHash links to a stored header hash, and maintain a mapping of hash→height (including initialization with a recent block hash). Also list common pitfalls + suggested unit tests/fixtures.

Step-by-step (no code) how to implement ERC-20 in Solidity/Foundry for ICT3009 Task 3 on top of my Task 2 contract. Include required ERC-20 functions/events (totalSupply, balanceOf, transfer, approve, allowance, transferFrom, Transfer, Approval), initial supply = 0, name/symbol/decimals setup, mint design so only the contract itself can mint (not externally callable; will be triggered later by Task 4), and burn design (burn and whether to include burnFrom). Also list revert/edge cases (zero address, insufficient balance/allowance), and provide a focused unit test checklist.

I’m working on ICT3009 Task 4 (Verify P2PKH/P2PK transaction inclusion + mint ERC-20 tokens) on top of my existing Solidity/Foundry project.

Context / existing code:

I already implemented:

BTCUtils.sha256d, BTCUtils.reverseBytes32, VarInt parsing helpers + tests

MerkleProofBTC.verifyMerkleProof(proof, root, leaf, index) (double-SHA256)

BitcoinHeaderChain that stores only block hashes and heights, verifies PoW from bits and chaining, and also stores the block’s merkleRoot (as stored in the header).

BtcVerifierToken ERC-20 with _mint internal only, initial supply 0, burn support, and a validatedTx mapping.

My current endianness convention:

Header block hash is stored/called as canonical/explorer-style bytes32 (digest reversed from sha256d(header)).

Merkle root is stored exactly as in the header field (call it merkleRootLE / internal order).

txid for merkle proof is sha256d(rawTx) (digest bytes used in merkle hashing).

Task 4 required interface (must match):

function verifyTransaction(
  bytes memory transaction,
  bytes32[] memory merkleProof,
  uint256 txIndex,
  bytes32 blockHash
) public returns (bool);


Task 4 requirements:

Validate blockHash corresponds to a known block stored in my contract.

Verify Merkle proof using my Task 1 verifier (verifyMerkleProof).

Prevent double validation: same tx can’t be validated twice.

Parse the transaction:

Ensure it has exactly 2 outputs (first is receiver, second is change).

Verify output0 is either:

P2PKH scriptPubKey: 76a914{20-byte PKH}88ac

P2PK scriptPubKey: 21{33-byte pubkey}ac or 41{65-byte pubkey}ac

Verify output0 is to a specific Bitcoin address (interpret this as checking against a provided 20-byte pubKeyHash or derived hash160(pubkey)).

Mint ERC-20 tokens equal to output0 value (satoshis) to the 20-byte public key hash of output0 (treat as Ethereum-like address by casting).

What I need from you (NO CODE YET):

A detailed, step-by-step implementation plan for verifyTransaction.

Exactly how to compute txid from transaction and keep byte order consistent with merkleRoot and verifyMerkleProof.

How to obtain the merkle root for blockHash from my header chain storage and which byte order to use.

A clear parsing plan for Bitcoin transactions:

offsets, varints, skipping inputs, reading outputs, extracting value and scriptPubKey.

how to enforce “exactly two outputs” robustly.

How to implement P2PKH detection and PKH extraction.

How to implement P2PK detection and how to derive the 20-byte hash from pubkey (sha256 then ripemd160).

Decide the best way to satisfy “specific Bitcoin address” requirement without changing the required function signature, and explain the tradeoffs. (If you think I must add an extra parameter, explain how to do it while still matching marking expectations.)

How to store/use the “already validated” tx mapping (which hash to key by).

A suggested test strategy in Foundry:

what to unit test with synthetic tx bytes vs real fixtures,

what fixtures I should generate (tx hex, merkle proof json, header), and what fields must match.

Common pitfalls: endianness mistakes, varint misuse, script parsing edge cases, index mistakes, incorrect hashing.

Finally: answer the documentation note:

why you can’t produce an Ethereum address matching the PKH,

suggest a clean improvement (claim mechanism) to map Bitcoin ownership to an Ethereum address.

Please keep this response structured and actionable, like a checklist of steps in the order I should implement, and include a small “minimum viable implementation” vs “nice-to-have” split.

I’m running Foundry tests for test/VerifyTransaction.t.sol and I’m getting 4 failures: test_verifyTransactionTo_enforces_expectedPKH() fails with custom error: "wrong recipient" test_verifyTransaction_doubleValidate_reverts(), test_verifyTransaction_legacy_emptyProof_mints_and_marksValidated(), and test_verifyTransaction_segwit_txid_strips_witness_and_works() fail with revert: "mint to zero" Here’s the trace pattern: verifyTransaction(...) / verifyTransactionTo(...) computes txid = sha256d(strippedTx) correctly (I see the two SHA256 precompile calls and the returned txid), then reverts with either "wrong recipient" or "mint to zero". In the failing cases, the test passes an expectedRecipient like 0x...aaaa and my code still reverts "wrong recipient". For the "mint to zero" failures, it looks like my mint target address is ending up as address(0) even though the tx outputs contain a P2PKH script like 76a914...<20 bytes>...88ac. Help me analyze and find and fix the errors

I’m working on ICT3009 Task 5: Integrate into a Unified System and Critique (10%).

Task 5 spec (summary):

Combine Tasks 1–4 into a cohesive smart contract system where:

Oracle posts block headers → contract verifies and stores them

User submits transaction proof

Contract verifies inclusion via Merkle proof, parses tx, checks output0 is P2PKH/P2PK, checks “specific recipient” requirement

Contract mints ERC20 tokens equal to output0 value to a generated address (derived from PKH)

Security: validate inputs, prevent double validation/spending

Test thoroughly (Forge/Foundry)

Critique flaws in system/spec and suggest improvements (in documentation)

Optional inspiration: Polygon Fx-Portal _validateAndExtractMessage

My current system status:

Task 1: MerkleProofBTC.verifyMerkleProof implemented and tested

Task 2: BitcoinHeaderChain implemented and tested (stores block hash + height, verifies PoW from bits + chaining, stores merkleRoot)

Task 3: ERC-20 implemented inside BtcVerifierToken (mint internal, supply starts 0, burn support) + tests passing

Task 4: verifyTransaction(...) implemented + tests passing (segwit txid stripping, prevents double validation, parses tx, supports P2PKH/P2PK, mints to PKH-derived address). Also added optional verifyTransactionTo(...) to enforce expected PKH.

What I need from you (structure it as an actionable checklist, then code plan, then critique plan):

Confirm what “integration” means here given my current architecture (BtcVerifierToken inherits HeaderChain + MerkleProof + ERC20 + verifyTransaction): am I already “unified” or do I need a wrapper/oracle role?

Concrete step-by-step instructions for finishing Task 5 with minimum changes, including:

Oracle posting flow: should I add access control (owner/oracle) for submitBlockHeader or leave it open? What does the spec likely expect?

How to expose/structure functions so the workflow is clear (e.g., events, view helpers).

Any missing validation checks you recommend (bounds checks, merkle root availability, tx format strictness, handling txIndex sanity, etc.)

A focused test plan for Task 5 that goes beyond unit tests:

“Happy path” full workflow test: submit header → verify tx → mint tokens

“Attack path” tests: invalid header, unknown block, bad proof, wrong recipient, double validation, malformed tx, etc.

Whether to use synthetic fixtures or real BTC fixtures; what minimum fixtures should be included.

A critique section plan:

List key flaws/limitations in the spec/system (oracle trust, address ownership mismatch, reorg risk, forks, no SPV chain work, difficulty checks, witness/txid pitfalls, etc.)

For each flaw: impact + suggested improvement (claim mechanism, proof of ownership, finality depth, chain selection by cumulative work, etc.)

Suggest how to present this in README/docs (headings, bullet format).

After the plan, provide the exact code changes you recommend (small, targeted diffs or full updated files if easier), including any:

Oracle gating / access control (if recommended)

Integration events

Helper views

Full integration tests

Keep the answer optimized for passing the marking rubric with minimal extra work, and clearly separate:

Minimum required for Task 5

Nice-to-have improvements (only if they won’t risk breaking earlier tasks/tests)


Ok. Here is the full coursework specification. You are my senior reviewer for ICT3009 “Bitcoin Transaction Verification on Ethereum”. Goal: Perform a full pre-submission audit of my coursework against the official specification. I want you to (1) confirm every requirement is met, (2) identify missing/weak parts, (3) flag subtle correctness bugs, and (4) produce a punch-list of fixes in priority order. Specification baseline (must check against): - Task 1 (Merkle proof verifier) signature + behavior - Task 2 (Bitcoin block header verification + chain + PoW + min difficulty 70B + height mapping) - Task 3 (ERC20: init supply 0, mint only via verifyTransaction, burn supported) - Task 4 (verifyTransaction: block known, merkle proof, prevent double validation, parse tx w/ 2 outputs, verify P2PKH or P2PK output to specific BTC address, mint to pubKeyHash-as-address) - Task 5 (integrated system + thorough tests + critique + suggested improvements) - Deliverables: source code, prompts used doc, deployment scripts/commands, README instructions, report <= 5 pages, zipped submission, steps documented (Please treat the spec as strict and point out any mismatch even if “probably fine”.) How to review: 1) Build a requirements traceability matrix mapping EACH bullet from the spec → (file + function + test) proving it’s satisfied. 2) Verify function signatures EXACTLY match the spec where required. 3) Review endianness assumptions for Bitcoin hashes/fields and confirm they’re consistent across: - sha256d, merkle proof hashing, txid handling, header hash handling, bits/target, merkleRoot extraction, prevHash checks 4) Review safety/security: - input bounds checks, revert reasons/custom errors, double-spend prevention, storage integrity, chain linking, PoW enforcement, difficulty floor, replay resistance 5) Review gas/efficiency only after correctness. 6) Review documentation quality: - README: compile, test, deploy, interact (with example commands) - Deployment scripts: exact Foundry commands and any env vars needed - AI prompts log: complete, well-formatted, includes prompts used during development - Report: <= 5 pages, explains design choices, challenges, and critique/suggested improvements (including “why pubKeyHash can’t map to an Ethereum address” + what to add) What I will provide (you tell me if anything else is needed, but try to proceed with what you have): A) Repository structure output: - ls -R of src/, test/, script/, docs/ B) Full contents of these files (I will paste or upload them): - src/BTCUtils.sol - src/MerkleProofBTC.sol - src/BitcoingHeaderChain.sol (or BitcoinHeaderChain.sol equivalent) - src/BtcVerifierToken.sol - Any other contracts used in integration - test/MerkleProof.t.sol - test/HeaderChain.t.sol - test/VerifyTransaction.t.sol - Any fixture files used for tests (header/tx/proof) - README.md - docs/ai-prompts.md (or the prompts-used document) - report.pdf (or report.md content) - script/Deploy.s.sol and any scripts used to demonstrate interaction C) Command outputs: - forge --version - forge build - forge test -vvv (full output) - If you use fuzz/integration tests, include those outputs too Your output format (must be concrete and actionable): 1) “Pass/Fail” checklist per task (Task 1–5) with exact evidence pointers (file + line or function name). 2) A missing-parts list (if any) ranked by grade risk. 3) A bug list ranked by severity (correctness > spec compliance > security > documentation > style). 4) A deployment/readme audit: what’s unclear or missing, with exact text to add. 5) A final “Submission readiness verdict” and a short punch-list of changes to do in the last 1–2 hours. Start by asking for the smallest set of artifacts you need first (e.g., README + forge test output + list of files), then proceed to deeper review once I provide contract and test files.